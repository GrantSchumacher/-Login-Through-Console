import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * CS2 HW1 UserLogin.java Description: Takes in a user's login input and checks
 * its validity based off of given requirements
 * 
 * @author grantschumacher
 * @version 1.0 8/30/17
 */
public class UserLogin {

	private Scanner sc = new Scanner(System.in);
	String[] sb;
	StringBuffer reportStringBuffer;
	private String userLogin;
	private String moreLoginResponse;
	private static boolean moreUserLogins = true;
	private boolean lengthOK;
	private boolean uppercaseOK;
	private boolean lowercaseOK;
	private boolean digitOK;
	private boolean specialCharOK;
	private boolean validity = true;

	public static void main(String[] args) {
		UserLogin newUserLogin = new UserLogin();
		while (moreUserLogins) { //Loop for as many logins as the user desires
			newUserLogin.greetUser();
			newUserLogin.readUser();
			newUserLogin.checkLength();
			newUserLogin.checkCase();
			newUserLogin.checkDigit();
			newUserLogin.checkSpecialChar();
			newUserLogin.checkValidity();
			newUserLogin.printReport();
			newUserLogin.checkMoreUserLogins();

		}

	}

	/**
	 * Greets User with a brief explanation of the program, written to the
	 * screen.
	 */
	public void greetUser() {
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("Hello, this is the user login page. Please enter your login to continue.");
		System.out.println("--------------------------------------------------------------------------");
		System.out.print("login: ");
	}

	public void checkMoreUserLogins() {
		moreLoginResponse = sc.next();
		if (moreLoginResponse.charAt(0) == 'Y' || moreLoginResponse.charAt(0) == 'y') { //Check for "yes" response
			moreUserLogins = true;
			userLogin = "";
			lengthOK = false;
			uppercaseOK = false;
			lowercaseOK = false;
			digitOK = false;
			specialCharOK = false;
			validity = true;
		} else if (moreLoginResponse.charAt(0) == 'N' || moreLoginResponse.charAt(0) == 'n') { //Check for "no" response
			moreUserLogins = false;
			System.out.println("--------------------------------------------------------------------------");
			System.out.println("No more logins to perform. Have a good day!");
		} else { //Check for invalid response
			System.out.print("Failed to enter valid response. Please try again: ");
			checkMoreUserLogins();
		}

	}

	/**
	 * Reads the user's input for login
	 */
	public void readUser() {
		userLogin = sc.next();
		
			userLogin += sc.nextLine();
		
		
		reportStringBuffer = new StringBuffer(userLogin);
	}

	/**
	 * Checks for at least one uppercase letter, returns true or false
	 * 
	 */
	public void checkCase() {

		for (int i = 0; i < userLogin.length(); i++) {
			if (Character.isUpperCase(userLogin.charAt(i))) { //Check for upper case letters
				uppercaseOK = true;
				break;
			}
		}

		for (int x = 0; x < userLogin.length(); x++) {
			if (Character.isLowerCase(userLogin.charAt(x))) { //Check for lower case letters
				lowercaseOK = true;
				break;
			}
		}

	}

	/**
	 * Checks the length of the login string, returns true or false
	 * 
	 */
	public void checkLength() {
		if (userLogin.length() >= 5) { //check length of word is >= 5
			lengthOK = true;
		} else {
			lengthOK = false;
		}
	}

	/**
	 * Checks the user login string for at least one digit
	 */
	public void checkDigit() {
		for (int x = 0; x < userLogin.length(); x++) {
			if (Character.isDigit(userLogin.charAt(x))) { //Check for digit in word
				digitOK = true;
				break;
			}
		}
	}

	/**
	 * Checks for at least one of the following special characters: !@#$
	 */
	public void checkSpecialChar() {
		for (int i = 0; i < userLogin.length(); i++) {

			if (userLogin.charAt(i) == '!' || userLogin.charAt(i) == '@' || userLogin.charAt(i) == '#'
					|| userLogin.charAt(i) == '$') { //Check for special characters
				specialCharOK = true;
				break;
			}

		}

		if (userLogin.contains("_") || userLogin.contains(" ") || userLogin.indexOf('\r') >= 0) { //Check for invalid characters: underscores, spaces, return keys
			specialCharOK = false;
		}

	}

	/**
	 * Checks whether or not all the login requirements are met
	 * 
	 * @return boolean validity
	 */
	public void checkValidity() {
		if (lengthOK == false) {
			addToReport("-- too short (minimum of 5 characters)");
			validity = false;
		}
		if (uppercaseOK == false) {
			addToReport("-- no uppercase letter");
			validity = false;
		}
		if (lowercaseOK == false) {
			addToReport("-- no lowercase letter");
			validity = false;
		}
		if (digitOK == false) {
			addToReport("-- no digit");
			validity = false;
		}
		if (specialCharOK == false) {
			addToReport("-- invalid special character");
			validity = false;
		}
		if (validity == true) { //If all of the tests are true
			printUser("(valid)");
		} else { //If one or more of the tests fail
			printUser("(invalid)"); 
		}
		System.out.println("--------------------------------------------------------------------------");
		System.out.print("Do you wish to perform another login? Type 'Y' for yes and 'N' for no: ");

	}

	/**
	 * Adds the error to the error list for the report
	 */
	public void addToReport(String report) {
		reportStringBuffer.append("//n");
		reportStringBuffer.append(report);

	}

	/**
	 * Prints validity result and error messages
	 * 
	 * @param loginValidity
	 */
	public void printUser(String loginValidity) {
		System.out.println(loginValidity);
		sb = reportStringBuffer.toString().split("//n");
		for (int i = 1; i < sb.length; i++) { //Iterate through the string buffer as an array and print each individual error
			System.out.println("  " + sb[i]);
		}
		reportStringBuffer.append(loginValidity);
	}

	/**
	 * Prints login results to report file
	 */
	public void printReport() {
		PrintWriter out;
		try { //If possible, write the login output to the UserLoginReport.txt file
			out = new PrintWriter(new FileWriter("UserLoginReport.txt", true), true);
			out.write("--------------------------------------------------------------------------");
			out.println();
			if (validity == true) {
				out.write("Login: " + userLogin + " (valid)");
			} else {
				out.write("Login: " + userLogin + " (invalid)");
			}
			out.println();
			for (int i = 1; i < sb.length; i++) {
				out.write("  " + sb[i]);
				out.println();
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
